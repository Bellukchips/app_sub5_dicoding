package com.example.submissonfinal_consumer.ViewModel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;
import com.example.submissonfinal_consumer.mapping.MappingHelper;
import com.example.submissonfinal_consumer.model.ModelMovie;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import cz.msebera.android.httpclient.Header;
import org.json.JSONObject;
import static com.example.submissonfinal_consumer.db.DatabaseContract.MovieColumn.*;
import java.util.ArrayList;

public class MainViewModel extends ViewModel {
    private static final  String API_KEY = "ed94c15844d5687a41edbd52b892330d";
    private MutableLiveData<ModelMovie> mutableLiveData = new MutableLiveData<>();
    private MutableLiveData<ArrayList<ModelMovie>> listMutableLiveDataFavoritMovies = new MutableLiveData<>();
    private MutableLiveData<ArrayList<ModelMovie>> listMutableLiveDataFavoritTv = new MutableLiveData<>();

    public void setFavoriteMovies(Context ctx){
        Uri uri = Uri.parse(CONTENT_URI+"/jenis/m");
        Cursor movies= ctx.getContentResolver().query(uri,null,null,null,null);
        ArrayList<ModelMovie> modelMovie = new ArrayList<>();
        modelMovie.clear();
        modelMovie = MappingHelper.mapCursor(movies);
        listMutableLiveDataFavoritMovies.postValue(modelMovie);
    }
    public void setFavoriteTv(Context ctx){
        Uri uri = Uri.parse(CONTENT_URI+"/jenis/t");
        Cursor movies= ctx.getContentResolver().query(uri,null,null,null,null);
        ArrayList<ModelMovie> modelMovie = new ArrayList<>();
        modelMovie.clear();
        modelMovie = MappingHelper.mapCursor(movies);
        listMutableLiveDataFavoritTv.postValue(modelMovie);
    }


    public LiveData<ArrayList<ModelMovie>> getFavoriteMovies(){
        return listMutableLiveDataFavoritMovies;
    }

    public LiveData<ArrayList<ModelMovie>> getFavoriteTv(){
        return listMutableLiveDataFavoritTv;
    }







    private static String url = "";
    public void setMovie(final Boolean type,int id_movie){
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        final  ModelMovie mMovie = new ModelMovie();
        if (type) {
            url="https://api.themoviedb.org/3/movie/"+id_movie+"?api_key="+API_KEY+"&language=en-US";
        } else {
            url="https://api.themoviedb.org/3/tv/"+id_movie+"?api_key="+API_KEY+"&language=en-US";
        }

        asyncHttpClient.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    String res = new String(responseBody);
                    JSONObject responeObj = new JSONObject(res);
                    ModelMovie modelMovie;
                    if (type){
                        modelMovie = new ModelMovie(responeObj,true);
                        mMovie.setJenis("1");

                    } else {
                        modelMovie = new ModelMovie(responeObj, false);
                        mMovie.setJenis("2");
                    }
                    mMovie.setName(modelMovie.getName());

                    mMovie.setDeskripsi(modelMovie.getDeskripsi());
                    mMovie.setTnggal(modelMovie.getTnggal());
                    mMovie.setId_movie(modelMovie.getId_movie());
                    mMovie.setPhoto(modelMovie.getPhoto());

                    mutableLiveData.postValue(mMovie);

                } catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.d("onFailure", error.getMessage());
            }
        });
    }



    public LiveData<ModelMovie> getMovie(){
        return mutableLiveData;
    }

}
