package com.example.submissonfinal_consumer.model;


import org.json.JSONObject;

public class ModelMovie {
    private String name;
    private String photo;

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    private String jenis;
    private int id_movie;
    private String tnggal;
    private String deskripsi;

    public ModelMovie(JSONObject obj, Boolean pindah_fragment) {
        String name, tnggal;
        try {
            int id = obj.getInt("id");
            if (pindah_fragment == true) {
                name = obj.getString("title");
                tnggal = obj.getString("release_date");

            } else {

                name = obj.getString("name");
                tnggal = obj.getString("first_air_date");

            }
            String deskripsi = obj.getString("overview");
            String image_path = obj.getString("poster_path");
            this.name = name;
            this.deskripsi = deskripsi;
            this.photo = image_path;
            this.tnggal = tnggal;
            this.id_movie = id;
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public ModelMovie() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public int getId_movie() {
        return id_movie;
    }

    public void setId_movie(int id_movie) {
        this.id_movie = id_movie;
    }

    public String getTnggal() {
        return tnggal;
    }

    public void setTnggal(String tnggal) {
        this.tnggal = tnggal;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }
}