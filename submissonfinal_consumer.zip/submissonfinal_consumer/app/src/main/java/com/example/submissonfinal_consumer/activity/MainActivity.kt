package com.example.submissonfinal_consumer.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.support.design.widget.BottomNavigationView
import com.example.submissonfinal_consumer.R
import com.example.submissonfinal_consumer.fragment.FavoriteMovieFragment
import com.example.submissonfinal_consumer.fragment.FavoriteTvFragment

class MainActivity : AppCompatActivity() {


    private val onNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
         R.id.navigation_favorite_film -> {
            val fv = FavoriteMovieFragment()
            supportFragmentManager.beginTransaction().replace(R.id.frame_container,fv).commit()
            setTitle(R.string.favorite_film)

            return@OnNavigationItemSelectedListener true
        }R.id.navigation_favorite_tv -> {
            val fv = FavoriteTvFragment()
            supportFragmentManager.beginTransaction().replace(R.id.frame_container,fv).commit()
            setTitle(R.string.favorite_tv_show)

            return@OnNavigationItemSelectedListener true
        }

        }
        false
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.more_vert,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item?.itemId== R.id.ac_settings){
            val i = Intent(Settings.ACTION_LOCALE_SETTINGS)
            startActivity(i)

        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val navView: BottomNavigationView = findViewById(R.id.nav_view)
        navView.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener)
        navView.selectedItemId = R.id.navigation_favorite_film
        setTitle(R.string.favorite)

    }
}

