package com.example.submissonfinal_consumer.activity

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.ContentValues
import android.graphics.Color
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.view.View
import android.widget.*
import com.bumptech.glide.Glide
import com.example.submissonfinal_consumer.R
import com.example.submissonfinal_consumer.ViewModel.MainViewModel
import com.example.submissonfinal_consumer.db.DatabaseContract.MovieColumn.*
import com.example.submissonfinal_consumer.mapping.MappingHelper
import com.example.submissonfinal_consumer.model.ModelMovie
import de.hdodenhof.circleimageview.CircleImageView
import java.lang.Exception
import java.text.NumberFormat

class DetailAcivity : AppCompatActivity() {

    private lateinit var name : TextView
    private lateinit var date : TextView
    private lateinit var desc : TextView
    private lateinit var img : ImageView
    private var idMovie : Int  =0
    private var jenis:Boolean = true
    private lateinit var pgrs: ProgressBar
    private lateinit var img_fav:ImageButton
    private val file_path = "https://image.tmdb.org/t/p/w342"
    private lateinit var mainViewModel:MainViewModel
    private lateinit var weHaveModel:ModelMovie
    private lateinit var idMovieUri:Uri
    private lateinit var insertMovieUri:Uri
    private lateinit var insertTvUri:Uri
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        weHaveModel = ModelMovie()
        mainViewModel = this@DetailAcivity.run {
            ViewModelProviders.of(this).get(MainViewModel::class.java)
        }
        mainViewModel.movie.observe(this,getMovie)

        idMovie = intent.getIntExtra("data",0)
        jenis = intent.getBooleanExtra("jenis",true)

        idMovieUri = Uri.parse(CONTENT_URI.toString() + "/" + idMovie)
        insertMovieUri = Uri.parse(CONTENT_URI.toString() + "/addmovie")
        insertTvUri = Uri.parse(CONTENT_URI.toString() + "/addtv")

        name = findViewById(R.id.judul)
        date = findViewById(R.id.tangggal)
        desc = findViewById(R.id.desc)
        img  = findViewById(R.id.img_d)
        img_fav = findViewById(R.id.img_fav)

        pgrs = findViewById(R.id.progressBar1)

        setData()


        img_fav.setOnClickListener {
            //            val search = movieHelper.search(weHaveModel.id_movie)
            val search = contentResolver.query(idMovieUri,null,null,null,null)
            val golet = MappingHelper.mapCursor(search)

            try{
                if (golet!=null){


//                    val del = movieHelper.deleteNote(weHaveModel.id_movie)
                    contentResolver.delete(idMovieUri,null,null)

                    img_fav.setColorFilter(ContextCompat.getColor(applicationContext,R.color.grey))
                    Toast.makeText(this@DetailAcivity,weHaveModel.name+" "+getString(R.string.data_deleted),Toast.LENGTH_LONG).show()


                } else {
                    val values = ContentValues()
                    values.put(ID_MOVIE,weHaveModel.id_movie)
                    values.put(JUDUL,weHaveModel.name)
                    values.put(DESC,weHaveModel.deskripsi)
                    values.put(DATE,weHaveModel.tnggal)
                    values.put(PHOTO,weHaveModel.photo)
                    try {
                        if(jenis){
                            values.put(JENIS,"1")

                            contentResolver.insert(insertMovieUri,values)
                        } else {
                            values.put(JENIS,"2")

                            contentResolver.insert(insertTvUri,values)
                        }
                    } catch (e : Exception){
                        Toast.makeText(this@DetailAcivity,"Error at Inserting : "+e.printStackTrace(),Toast.LENGTH_LONG).show()
                    }


                    img_fav.setColorFilter(ContextCompat.getColor(applicationContext,R.color.colorAccent))
                    Toast.makeText(
                        this@DetailAcivity,weHaveModel.name+" "+
                                getString(R.string.insert_data_success),
                        Toast.LENGTH_LONG
                    ).show()

                }
            } catch (e : Exception){
                e.printStackTrace()
            }

        }


    }

    private fun setData() {
        try {
            if(jenis){
                mainViewModel.setMovie(true,idMovie)

            } else {
                mainViewModel.setMovie(false,idMovie)
            }
            showLoading(true)
        } catch (e:Exception){
            e.printStackTrace()
        }
    }

    private val getMovie =
        Observer<ModelMovie> { getMovie ->
            if (getMovie != null) {
                name.text = getMovie.name
                desc.text = getMovie.deskripsi
                val nm = NumberFormat.getInstance()
                Glide.with(this).load(file_path+getMovie.photo).into(img)
                date.text =getMovie.tnggal
                weHaveModel = getMovie
//                val cari = movieHelper.search(getMovie.id_movie)

                val cari = contentResolver.query(idMovieUri,null,null,null,null)
                val golet = MappingHelper.mapCursor(cari)

                if (golet!=null){
                    img_fav.setColorFilter(ContextCompat.getColor(applicationContext,R.color.colorAccent))

                } else {
                    img_fav.setColorFilter(ContextCompat.getColor(applicationContext,R.color.grey))

                }
                showLoading(false)
            }
        }



    private fun showLoading(isLoading: Boolean?){
        if (isLoading==true){
            pgrs.visibility = View.VISIBLE
            name.visibility = View.INVISIBLE
            desc.visibility = View.INVISIBLE
            date.visibility = View.INVISIBLE
            img.visibility = View.INVISIBLE
            img_fav.visibility = View.INVISIBLE

        } else {
            pgrs.visibility = View.GONE
            name.visibility = View.VISIBLE
            desc.visibility = View.VISIBLE
            date.visibility = View.VISIBLE
            img.visibility = View.VISIBLE
            img_fav.visibility = View.VISIBLE
        }
    }

}
