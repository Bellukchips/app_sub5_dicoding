package com.example.submission3dicoding.fragment;


import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.submission3dicoding.R;
import com.example.submission3dicoding.adapter.ViewPagerAdapter;

/**
 * A simple {@link Fragment} subclass.
 */
public class FavoriteFragment extends Fragment {


    public FavoriteFragment() {
        // Required empty public constructor
    }

    private ViewPagerAdapter adapter;
    private ViewPager viewPager;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View  view = LayoutInflater.from(container.getContext()).inflate(R.layout.fragment_favorite,container,false);
        viewPager = view.findViewById(R.id.viewPager);

        adapter = new ViewPagerAdapter(getFragmentManager());
        adapter.addFragment(new FavoriteMovieFragment(),"Tab Movie");
        adapter.addFragment(new FavoriteTvShowFragment(),"Tab TV");
        viewPager.setAdapter(adapter);
        return view;
    }


}
